"""
Blueprint package for Azure Functions.
"""
